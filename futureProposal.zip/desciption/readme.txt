note:
the src/ folder is what is given to the student
the myProgram.cpp is a possible output from the program written by the student

THE CODE CONTAINED IN /SRC DIRECTORY IS NOT MY OWN. IT IS AN OPEN SOURCE PROJECT MADE BY TENCENT.
the souce program could be any mid-size project that will be difficult to combine into an amalgamated file.
I used this one as an example.